package com.gpjava.gpjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GpjavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GpjavaApplication.class, args);
	}

}
