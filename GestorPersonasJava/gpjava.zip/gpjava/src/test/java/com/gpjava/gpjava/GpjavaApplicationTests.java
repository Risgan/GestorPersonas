package com.gpjava.gpjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpjavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
